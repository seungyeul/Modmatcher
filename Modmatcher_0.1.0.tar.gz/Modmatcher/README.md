# Modmatcher
## R package for sample alignment

### Installation of the package
R CMD INSTALL Modmatcher_0.1.0.tar.gz

### R scripts for the all functions
R/modmatcher.R

### Example datasets including gender information
data/*.rda

### Vignette link
https://rpubs.com/seungyeul/471026

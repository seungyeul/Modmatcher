## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- fig.show='hold', fig.dim=c(7,7)------------------------------------
    library(Modmatcher)
    data<-set1_rnaseq 
    ann_gender<-set1_gender[match(colnames(data),set1_gender[,1]),2]
    gender<-ifelse(is.na(ann_gender),3,ifelse(ann_gender=="Female",1,2))
    gen_tab<-gender_sig(data,gender)
    first<-gen_tab[1,1] # The most separating genes between genders: RPS4Y1
    second<-gen_tab[2,1] # The second best separating genes between genders: DDX3Y
    gender_check(data,first,second,gender)

## ---- fig.show='hold',fig.dim=c(7,7)-------------------------------------
    data<-set2_microarray 
    ann_gender<-set2_gender[match(colnames(data),set2_gender[,1]),2]
    gender<-ifelse(is.na(ann_gender),3,ifelse(ann_gender=="Female",1,2))
    gen_tab<-gender_sig(data,gender)
    first<-"RPS4Y1"
    second<-"XIST"
    gender_check(data,first,second,gender)

## ---- echo=TRUE, results='asis'------------------------------------------
    rnd=1
    
    type1<-"microarray"
    type2<-"CNV"
    
    data1<-set2_microarray
    data2<-set2_cnv

    type1<-"microarray"
    type2<-"CNV"
    
    ### For round 1 of iteration, the samples are paired based on initial labels.
    sam1<-intersect(colnames(data1),colnames(data2))
    sam2<-sam1

    # Get the same features from the two matrices
    gene1<-rownames(data1)
    gene2<-rownames(data2)
    com_gene<-intersect(gene1,gene2)

    # Filter the common genes and the same labeled sampled (or matching) samples.
    ndata1<-data1[match(com_gene,gene1),match(sam1,colnames(data1))]
    ndata2<-data2[match(com_gene,gene2),match(sam2,colnames(data2))]

    ## If there are any samples without matching pairs, they are matched crossly with other samples.
    odata1<-data1[match(com_gene,gene1),which(!(colnames(data1)%in%sam1))]
    odata2<-data2[match(com_gene,gene2),which(!(colnames(data2)%in%sam2))]

    # Call cis_pair() and save the table into cis_tab
    cis_tab<-cis_pair(ndata1,ndata2)
    rownames(cis_tab)<-NULL
    knitr::kable(head(cis_tab, 10))

## ---- echo=TRUE, results='asis'------------------------------------------
    sel_num<-min(1000,5*min(dim(data1)[[2]],dim(data2)[[2]]),length(which(as.numeric(cis_tab[,4])<0.01)))
    cis_tab<-cis_tab[1:sel_num,]
    cis_dir<-as.numeric(cis_tab[,2])
    cis_gene<-as.character(cis_tab[,1])
    sam_1<-c(sam1,colnames(odata1))
    sam_2<-c(sam2,colnames(odata2))
    sam_pair<-paste(sam_1, sam_2)
    sdata1<-data1[match(cis_gene,gene1),match(sam_1,colnames(data1))]
    sdata2<-data2[match(cis_gene,gene2),match(sam_2,colnames(data2))]

    ## For the negatively assocated features, we reversed their ranking by multiplying -1.
    sdata2[which(cis_dir<0),]<- -(sdata2[which(cis_dir<0),])

    ## Estimating sample similarity score calling sam_score()
    score<-sam_score(sdata1,sdata2,"RNAseq","Proteome")

## ---- echo=F, fig.show='hold', fig.dim=c(7,7)----------------------------
    # Determination of cutoff based on z-transformed distribution of scores
  	# Top 5% or top 2.5% (ci; 5 or 2.5)
    match1<-as.numeric(apply(score,1,function(x) which(x==max(x))))
	  match2<-as.numeric(apply(score,2,function(x) which(x==max(x))))
  	best1<-rep(0,length(match1))
  	best2<-rep(0,length(match2))
    new_score<-score[1:length(sam1),1:length(sam2)]
    top<-5
	  cut1<-rep(0,length(rownames(new_score)))
	  cut2<-cut1
	  ci<-ifelse(top==5,1.645,1.960)
	  for(i in 1:length(cut1)){
		  sim_row<-as.numeric(new_score[i,])
		  fis_mat<-0.5*(log(1+sim_row)-log(1-sim_row))
		  cut<-mean(fis_mat)+ci*sd(fis_mat)
		  cut1[i]<-length(which(fis_mat>cut))
		  sim_col<-as.numeric(new_score[,i])
	  	fis_mat<-0.5*(log(1+sim_col)-log(1-sim_col))
		  cut<-mean(fis_mat)+ci*sd(fis_mat)
		  cut2[i]<-length(which(fis_mat>cut))
	  }
	  topN1<-round(mean(cut1))
	  topN2<-round(mean(cut2))

    # Initial alignment for the pre-aligned pairs
	  new_sam1<-rownames(new_score)
	  new_sam2<-colnames(new_score)
    diff1<-rep(0,length(new_sam1))
    diff2<-diff1
    secd1<-rep(0,length(new_sam2))
    secd2<-secd1
	  self_tab<-matrix(NA,nr=length(new_sam1),nc=8)
	  colnames(self_tab)<-c("Sample1","Sample2","selfscore","cut1","cut2","rank1","rank2","Note")
	  for(i in 1:length(new_sam1)){
      name1<-new_sam1[i]
      name2<-new_sam2[i]
      self<-new_score[i,i]
      row_scr<-as.numeric(new_score[i,])
		  scr1<-sort(row_scr,decreasing=T)
      mean1<-mean(scr1)
      sec1<-scr1[2]
      diff1[i]<-self-mean1
      secd1[i]<-self-sec1
      cut1<-scr1[topN1]
		  rank1<-which(scr1==self)
		  col_scr<-as.numeric(score[,i])
      scr2<-sort(col_scr,decreasing=T)
      mean2<-mean(scr2)
      sec2<-scr2[2]
      cut2<-scr2[topN2]
		  rank2<-which(scr2==self)
      diff2[i]<-self-mean2
      secd2[i]<-self-sec2
      sam_col<-rep("grey",length(sam1))
      sam_col[i]<-"red"
      if(self>=cut1&self>=cut2){
        note<-"Ok"
      } else if(self>=cut1|self>=cut2){
        note<-"Poor"
      } else {
        note<-"No"
			  row_ind<-which(row_scr==max(scr1))
			  col_ind<-which(col_scr==max(scr2))
			  sam_ind<-c(row_ind,col_ind)
			  no_sam<-c(sam1[row_ind],sam2[col_ind])
			  sam_col[sam_ind]<-"blue"
      }
      self_tab[i,]<-c(name1,name2,self,cut1,cut2,rank1,rank2,note)
	  }
	  plot(diff1,diff2,xlab=paste(type1,"->",type2),ylab=paste(type2,"->",type1),main="Self_score - mean(other)",cex.axis=1.2,cex.lab=1.5,cex.main=2)
    abline(0,1,lty=2,col="red")
    plot(secd1,secd2,xlab=paste(type1,"->",type2),ylab=paste(type2,"->",type1),main="Self_score - second_best_score",cex.axis=1.2,cex.lab=1.5,cex.main=2)
    abline(0,1,lty=2,col="red")

## ---- echo=F, fig.show='hold', fig.dim=c(7,7)----------------------------
    name1<-"MMRC0001"
    name2<-name1
    row_scr<-as.numeric(new_score[name1,])
    col_scr<-as.numeric(new_score[,name2])
    sam_col<-rep("grey",length(sam1))
    sam_ind<-which(new_sam1==name1)
    sam_col[sam_ind]<-"red"
    plot(row_scr,col_scr,col=sam_col,xlab=paste(type1,":",name1," vs ",type2,":All",sep=""),ylab=paste(type1,":All vs ",type2,":",name2,sep=""),main=paste("Data1:",name1,"- Data2:",name2))
		name1<-"MMRC0197"
		name2<-name1
    row_scr<-as.numeric(new_score[name1,])
    col_scr<-as.numeric(new_score[,name2])
    sam_col<-rep("grey",length(sam1))
    sam_ind<-which(new_sam1==name1)
    sam_col[sam_ind]<-"red"
    plot(row_scr,col_scr,col=sam_col,xlab=paste(type1,":",name1," vs ",type2,":All",sep=""),ylab=paste(type1,":All vs ",type2,":",name2,sep=""),main=paste("Data1:",name1,"- Data2:",name2))
    text(row_scr[sam_ind]-0.1,col_scr[sam_ind]-0.02,no_sam)

## ---- echo=F, results='asis'---------------------------------------------
    ok_sam<-self_tab[which(self_tab[,8]=="Ok"),]
    pr_sam<-self_tab[which(self_tab[,8]=="Poor"),]
    no_sam<-self_tab[which(self_tab[,8]=="No"),]
    com_sam<-rbind(ok_sam[1:3,],pr_sam[1:3,],no_sam[1:3,])
    knitr::kable(com_sam)

## ---- echo=T, results='asis'---------------------------------------------
    ok_sam<-self_tab[which(self_tab[,8]=="Ok"),]
	  sam1_ok<-ok_sam[,1]
	  sam2_ok<-ok_sam[,2]
	  best1[match(sam1_ok,rownames(score))]<-match(sam2_ok,colnames(score))
	  best2[match(sam2_ok,colnames(score))]<-match(sam1_ok,rownames(score))
	  # reciprocal alignment
    no_sam1<-sam_1[!(sam_1%in%sam1_ok)]
    no_sam2<-sam_2[!(sam_2%in%sam2_ok)]
    if(length(no_sam1)>0){
		  for(i in 1:length(no_sam1)){
			  name1<-no_sam1[i]
			  ind1<-which(sam_1==name1)
			  part1<-match1[ind1]
			  name2<-sam_2[part1]
			  ind2<-which(sam_2==name2)
			  part2<-match2[ind2]
			  if(ind1==part2&name2%in%no_sam2){
				  best1[ind1]<-ind2
				  best2[ind2]<-ind1
				  print(paste(type1,":",name1,"->",type2,":",name2))
			  }
		  }
    }

## ---- echo=T, results='asis'---------------------------------------------
  final1<-sam_1[best1>0]
	final2<-sam_2[best1[best1>0]]
	final_pair<-paste(final1,final2)
	flag<-ifelse(final1==final2,"Self-aligned","Cross-aligned")
	final_tab<-cbind(final1,final2,flag)
	colnames(final_tab)<-c(type1,type2,"Note")
	token<-ifelse(length(final_pair)==length(intersect(final_pair,sam_pair)),1,0)
	final_tab<-final_tab[sort.list(final_tab[,3]),]
	knitr::kable(final_tab[1:10,])
	print(paste("Final token=",token))

## ---- echo=F, results='hide'---------------------------------------------
    rm(list=ls())
    data1<-set2_microarray
    data2<-set2_cnv
    run_tok=0
    rnd=1
    while(run_tok==0&rnd<10){
        run_tok<-pairwise_alignment(data1,data2,"microarray","CNV",rnd)
        rnd<-rnd+1
    }

## ---- echo=F, fig.show='hold', fig.dim=c(7,7)----------------------------
    type1<-"microarray"
    type2<-"CNV"
    num_sam<-rep(0,rnd)
	  num_cis<-rep(0,rnd)
	  for(i in 1:(rnd-1)){
		  cis_tab<-read.table(paste(type1,"_",type2,"_Round_",i,"/",type1,"_",type2,"_cis_pairs.txt",sep=""),header=T,sep="\t")
		  num_cis[i]<-length(which(cis_tab$q.value<0.01))
		  if(i == 1){
        num_sam[i]<-length(intersect(colnames(data1),colnames(data2)))
			  cis_first<-cis_tab
      } else {
        pre_align<-read.table(paste(type1,"_",type2,"_Round_",i,"/Alignment_pairs.txt",sep=""),header=T,sep="\t")
        num_sam[i]<-dim(pre_align)[[1]]
      }
	  }
	  num_sam[rnd]<-num_sam[rnd-1]
	  num_cis[rnd]<-num_cis[rnd-1]

	  # Relationship between the number of sample and the number of cis genes along the sample alignment rounds
	  par(mar=c(5, 4, 4, 5) + 0.1)
	  plot(seq(1,rnd),num_cis,pch=16,xlab="",ylab="",axes=F,type="b",col="red",main="Sample alignment quality")
	  axis(4,col="red",col.axis="red",las=0)
	  mtext("Number of cis associated genes",col="red",side=4,line=2.5)
	  box()

  	par(new=T)

	  plot(seq(1,rnd),num_sam,pch=15,xlab="",ylab="",axes=F,type="b",col="blue")
	  mtext("Numbe of aligned sample",col="blue",side=2,line=4)
	  axis(2,col="blue",col.axis="blue",las=0)

  	axis(1,1:rnd,labels=as.character(c(0:(rnd-1))))
	  mtext("Alignment round",side=1,col="black",line=2.5)
	
	  # Comparison of cis strength from the first round to the last
	  cis_tab<-cis_tab[match(cis_first[,1],cis_tab[,1]),]
	  first_qva<- -log10(cis_first[,4])
	  last_qva<- -log10(cis_tab[,4])
	  plot(first_qva,last_qva,xlab="-log10(FDR) - First round",ylab="-log10(FDR) - Last round",main="Cis assoication strength")
  	abline(0,1,lty=2,col="red")

